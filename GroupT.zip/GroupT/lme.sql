-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 14, 2017 at 08:29 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lme`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `account_id` int(99) NOT NULL AUTO_INCREMENT,
  `account_first_name` varchar(200) NOT NULL,
  `account_last_name` varchar(200) NOT NULL,
  `password` varchar(99) NOT NULL,
  `username` varchar(99) NOT NULL,
  `email` varchar(99) NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`account_id`, `account_first_name`, `account_last_name`, `password`, `username`, `email`) VALUES
(1, 'Kai', 'Ge', 'a12345678', 'KAI', 'kai@gmail.com'),
(2, 'Karishma', 'Patel', 'a12345678', 'KARISHMA', 'karishma@gmail.com'),
(3, 'Roshna', 'Shany', 'a12345678', 'ROSHNA', 'roshna@gmail.com'),
(34, 'JOON', 'FJERG', 'heaven45', 'JOONY', 'joonfjerg@gmail.com'),
(35, 'Julius', 'Ceasar', 'thedestroyer', 'JCeaser', 'JC@msn.com');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(99) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'rock'),
(2, 'classic'),
(3, 'hiphop'),
(4, 'country');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
CREATE TABLE IF NOT EXISTS `event` (
  `event_id` int(99) UNSIGNED NOT NULL AUTO_INCREMENT,
  `event_name` varchar(200) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `location_id` int(99) UNSIGNED NOT NULL,
  `account_id` int(99) UNSIGNED NOT NULL,
  `category_id` int(99) UNSIGNED NOT NULL,
  `sale_start_date` datetime NOT NULL,
  `sale_end_date` datetime NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `event_name`, `description`, `location_id`, `account_id`, `category_id`, `sale_start_date`, `sale_end_date`, `start_date`, `end_date`) VALUES
(1, 'The Violin Concerto in E minor, Op. 64', 'A classic and historical violin concerto which will be performance by many famous violin players', 3, 1, 2, '2018-12-01 00:00:00', '2019-01-01 00:00:00', '2019-02-01 18:00:00', '2019-02-01 21:00:00'),
(2, 'British country female singer festival', 'Selected exceptional British country singers performance together to celebrate this annual festival', 1, 2, 4, '2016-12-01 00:00:00', '2017-02-01 00:00:00', '2017-03-01 18:00:00', '2017-03-03 21:00:00'),
(3, 'Coldplay annual concert', 'One of the most popular rock band leading audiences to a wonderful rock time ', 1, 3, 1, '2016-12-01 00:00:00', '2017-01-01 00:00:00', '2017-02-01 15:00:00', '2017-02-01 18:00:00'),
(4, 'ACDC concert', 'A well-known metal rock band holding an annual concert ', 1, 2, 1, '2017-03-01 00:00:00', '2017-04-01 00:00:00', '2017-06-01 18:00:00', '2017-02-01 21:00:00'),
(5, 'Random Event', 'How do I know that', 5, 1, 1, '2017-12-10 00:00:00', '2017-12-15 00:00:00', '2018-11-11 00:00:00', '2018-11-12 00:00:00'),
(19, 'Kings of Kari', 'Entertaining Family Band', 3, 2, 3, '2017-12-14 19:46:20', '2017-12-14 19:56:20', '2017-12-14 19:57:20', '2017-12-14 19:58:20'),
(20, 'Moon River', 'Theatrical melodies inspired by the one and only Audrey Hepburn', 3, 1, 2, '2017-12-14 19:54:20', '2018-01-10 19:54:20', '2018-01-11 12:20:20', '2018-01-12 12:20:20'),
(21, 'Roman Bash', 'A blast from the past', 4, 35, 1, '2018-02-09 13:00:00', '2018-12-10 12:20:20', '2019-02-11 12:20:20', '2019-02-12 12:00:40');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `text` varchar(10000) NOT NULL,
  `rating` enum('1','2','3','4','5') NOT NULL,
  `account_id` int(99) UNSIGNED NOT NULL,
  `event_id` int(99) UNSIGNED NOT NULL,
  PRIMARY KEY (`account_id`,`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`text`, `rating`, `account_id`, `event_id`) VALUES
('good', '5', 2, 2),
('coldplay!', '5', 3, 3),
('A brand new music style to me. I really don\'t like it. it\'s too noisy.', '1', 4, 4),
('great. ', '5', 2, 19),
('Good! Could have been improved if the number of musical instruments used were reduced.', '2', 34, 19);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
CREATE TABLE IF NOT EXISTS `location` (
  `location_id` int(99) UNSIGNED NOT NULL AUTO_INCREMENT,
  `location_name` varchar(200) NOT NULL,
  `address` varchar(10000) NOT NULL,
  `Capacity` int(11) NOT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location_id`, `location_name`, `address`, `Capacity`) VALUES
(1, 'The O2 Arena', 'Peninsula Square, London SE10 0DX', 1000),
(2, 'Wembley Arena', 'Arena Square, Engineers Way, London HA9 0AA', 2000),
(3, 'Royal Albert Hall', 'Kensington Gore, Kensington, London SW7 2AP', 500),
(4, 'Richard Mully\'s Basement Bar', 'Basement of Lewis\'s building at 136 Grower Street, The Richard Mull\'s Basement bar', 100),
(5, 'The Huntley', 'Lewis Building (ground floor), 134-136 Grower Street, London, WC1E 6BP', 30);

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
CREATE TABLE IF NOT EXISTS `ticket` (
  `ticket_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `event_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`ticket_id`,`event_id`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`ticket_id`, `event_id`, `account_id`) VALUES
(1, 2, 2),
(84, 3, 3),
(89, 2, 1),
(85, 3, 1),
(95, 5, 2),
(96, 19, 34),
(97, 19, 3),
(98, 19, 2),
(99, 19, 1),
(100, 20, 1),
(101, 20, 35);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
