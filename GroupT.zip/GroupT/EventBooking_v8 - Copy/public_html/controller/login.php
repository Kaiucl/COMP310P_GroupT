<?php
//Controller for submitting the form to login in 3_signIn
session_start();
include ("../controller/connect.php");

function stayOnPage($alerts) {
    echo "<script language=\"JavaScript\">\n";
    echo "alert('$alerts.');\n";
    echo "window.location='../php/3_signIn.php'";
    echo "</script>";
}
function login(){
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    




    $connection =connect()
      
    or die('Error connecting to MySQL server.'.
        mysql_error());

    $query = "SELECT account_first_name, account_last_name, username, password FROM `account` WHERE username =\"{$username}\" AND password =\"{$password}\"";
    $result = mysqli_query($connection,$query)
    or die('Error making select users query'.mysql_error());
    $row = mysqli_fetch_array($result);
    
    if(mysqli_num_rows($result)>0){
        $check_username = $row['username'];
        $check_password = $row['password'];
    
        if($username == $check_username && $password == $check_password){
            
            $_SESSION["user"]=$row['username']; 
            //echo $_SESSION["user"];
            echo "<script language=\"JavaScript\">\n";
            echo "alert('Welcome ".$row['account_first_name'] . " " . $row['account_last_name']."! You are now logged in.');\n";
            echo "window.location='../controller/index.php?page=4_homePage'";
            echo "</script>";
            
        }

        else{
            $alerts = "Incorrect username or password";
           stayOnPage($alerts);
        }
    }
    else{
        $alerts = "Invalid username or password.";
           stayOnPage($alerts);
      
    }
    

   
}

login();
