<?php
//Controller for hosted events table in 7_myAccount page
$connection = connect();
$hostedSql = "SELECT event_name, start_date, event_id FROM event WHERE account_id='$user_id'";

$hostedResult = mysqli_query($connection,$hostedSql);
$hostedRow = mysqli_fetch_array($hostedResult);
$hostedRow['event_name'];
$hostedRow['start_date'];

if (empty($hostedRow)){
    echo"
<table>
        <caption>Your Hosted Events</caption>
        <th>No hosted events</th>
</table>";
}
else{
    echo"
  <table>
  <caption>Your Hosted Events</caption>
        <tr>
            <th>Event Name</th>
            <th>Start Date</th>
        </tr>
  </table>";
    

    do {echo "<table>
           <tr>
               <td><a href=\"../php/8_eventsHost.php?event_id={$hostedRow['event_id']}\">{$hostedRow['event_name']}</a></td>
               <td>{$hostedRow['start_date']}</td>
              
           </tr>
           </table>";
    }
    while ($hostedRow = mysqli_fetch_array($hostedResult));
}
?>