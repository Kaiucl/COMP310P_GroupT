<?php
include ("../controller/connect.php");
//Controller for submitting the form to create login in 2_signUp
?>
<?php

$su_firstName=$_POST["firstName"];
$su_lastName=$_POST["lastName"];
$su_username=$_POST["username"];
$su_email=$_POST["email"];
$su_password=$_POST["password"];
$su_confirmPassword=$_POST["password1"];



function testInput($data){
    $data = trim($data);
    /*$data = stripslashes($data);
    $data = htmlspecialchars($data);*/
    return $data;
}
function stayOnPage($alerts){
        echo "<script language=\"JavaScript\">\n";
        echo "alert('$alerts.');\n";
        echo "window.location='../php/2_signUp.php'";
        echo "</script>";
        
}
if ($_SERVER["REQUEST_METHOD"]=="POST"){
        $connection = connect();
        $usernamequery ="SELECT username FROM account WHERE username= \"{$su_username}\"";
        $usernameresult = mysqli_query($connection,$usernamequery)
        or die('Error making select users query'.mysql_error());
        $usernamerow = mysqli_fetch_array($usernameresult);
 
        
    if (!preg_match("/^[a-zA-Z ]*$/",$su_firstName)){
        $alerts = "For first names and last names, please use only letters and spaces. No hyphens or other special characters";
        stayOnPage($alerts);
        
    }
   
    else if(!preg_match("/^[a-zA-Z ]*$/",$su_lastName)){
       $alerts = "For first names and last names, please use only letters and spaces. No hyphens or other special characters";
       stayOnPage($alerts);
    }
    
    else if (preg_match('/[^0-9a-z\s-]/i',$su_username)){
        $alerts = "Please enter a username using only numbers, letters, dashes and spaces.";
        stayOnPage($alerts);
    }
    
    else if(mysqli_num_rows($usernameresult)>0){
        $alerts = "Sorry, this username is already in use, please choose another username";
        stayOnPage($alerts);
    }
   
    else if (!filter_var($su_email, FILTER_VALIDATE_EMAIL)) {
        $alerts = "Invalid email address";
        stayOnPage($alerts);
    }

    else if (strlen($su_password)<8) {
        $alerts = "Password too short";
        stayOnPage($alerts);
    }

    else if (!preg_match("#[a-zA-Z]+#", $su_password)) {
        $alerts = "Password must include at least one letter!";
        stayOnPage($alerts);
    }

    else if($su_confirmPassword!=$su_password){
        $alerts = "Please check that your passwords match";
        stayOnPage($alerts);
    }


    else{
        $su_firstName = testInput($su_firstName);    
        $su_username = testInput($su_username);
        $su_lastName = testInput($su_lastName);
        $su_email = testInput($su_email);
        $su_password = testInput($su_password);
        $su_confirmPassword = testInput($su_confirmPassword);
        //$_SESSION["user"]=$su_username;
        $connection = connect();
        $query ="INSERT INTO account(account_first_name, account_last_name, password, username, email) VALUES (\"{$su_firstName}\", \"{$su_lastName}\", \"{$su_password}\", \"{$su_username}\" , \"{$su_email}\") ";
        $result = mysqli_query($connection,$query)
        or die('Error making select users query'.mysql_error());
        echo "<script language=\"JavaScript\">\n";
        echo "alert('You have created an account!');\n";
        echo "window.location='../controller/index.php?page=3_signIn'";
        echo "</script>";
    }       

    }