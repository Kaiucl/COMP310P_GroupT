<?php
//Controller to store session for username
$connection=connect();

$username=$_SESSION["user"];
$account_id = "SELECT account_id, username, email FROM account WHERE username =\"{$username}\"";
$accountIdResult = mysqli_query($connection,$account_id)
or die('Error making select location_id query' . mysql_error());
$accountRow = mysqli_fetch_array($accountIdResult);
$accountRow['account_id'];
$accountRow['username'];
$accountRow['email'];

$user_id=$accountRow['account_id'];

?>