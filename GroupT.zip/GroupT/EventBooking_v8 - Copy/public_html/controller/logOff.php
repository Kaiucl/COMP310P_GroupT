<?php
//Controller to log out of session in 7_myAccount page
session_start();
session_destroy();
echo "<script language=\"JavaScript\">\n";
          echo "alert('You have logged off');\n";
          echo "window.location='../controller/index.php?page='";
          echo "</script>";
