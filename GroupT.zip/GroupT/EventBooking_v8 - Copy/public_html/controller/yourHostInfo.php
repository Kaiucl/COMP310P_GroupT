<?php
//Controller to display hosted event infromation in 8_eventsHost page
$connection=connect();
$event_id = (int)$_GET['event_id'];

$hostSql = "SELECT event.event_id, event_name, start_date, location_name, capacity FROM event JOIN location ON event.location_id = location.location_id WHERE event.event_id = '$event_id'";
//echo $hostSql;
$hostResult = mysqli_query($connection,$hostSql);
$hostRow = mysqli_fetch_array($hostResult);
$hostRow['event_id'];
$hostRow['event_name'];
$hostRow['start_date'];
$hostRow['location_name'];
$hostRow['capacity'];

$ticketSql="SELECT COUNT(ticket.account_id) FROM event JOIN ticket ON event.event_id = ticket.event_id WHERE event.event_id = '$event_id'";
//echo $ticketSql;
$ticketResult = mysqli_query($connection,$ticketSql);
$ticketRow = mysqli_fetch_array($ticketResult);
$ticketRow['COUNT(ticket.account_id)'];
$ticketRemain = $hostRow['capacity']-$ticketRow['COUNT(ticket.account_id)'];

$atdSql="SELECT username, email FROM ticket JOIN event ON event.event_id = ticket.event_id JOIN account ON account.account_id = ticket.account_id WHERE event.event_id = '$event_id'";
$atdResult = mysqli_query($connection,$atdSql);
$atdRow = mysqli_fetch_array($atdResult);
$atdRow['username'];
$atdRow['email'];

