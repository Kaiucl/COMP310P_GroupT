<?php
//Controller for submitting the feedback in 11_submitFeedabck page
session_start();
//$event_id = (int)$_GET['event_id'];
//$_SESSION["feedback_event_id"]= $event_id;
include ("../controller/connect.php");
include ("../controller/checkState.php");

$connection=connect();
if(isset($_SESSION["feedback_event_id"])){$event_id=(int)$_SESSION["feedback_event_id"];}
//$event_id = (int)$_SESSION["feedback_event_id"];
//echo $event_id;

function stayOnPage($alerts){
        echo "<script language=\"JavaScript\">\n";
        echo "alert('$alerts.');\n";
        echo "window.location='../controller/index.php?page=7_myAccount'";
        echo "</script>";
        
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $ratingValue = $_POST["rating"];
    $feedbackText = $_POST["feedback_text"];

    $query = "SELECT account_id, event_id FROM `feedback` WHERE account_id ='$user_id' AND event_id ='$event_id'";
    //echo $query;
    $result = mysqli_query($connection,$query)
    or die('Error making select users query'.mysql_error());
    $row = mysqli_fetch_array($result);
    $row['account_id'];
    $row['event_id'];
    //echo $row['account_id'];
    //echo $row['event_id'];

    if(!empty($row['account_id'])){
        $alerts = "sorry you have already given feedback";
        stayOnPage($alerts);
    }
    else{
      
      
   $submitFeedbackSQL= "INSERT INTO feedback(text, rating, account_id, event_id) VALUES ('$feedbackText', '$ratingValue','$user_id','$event_id')";
   //echo $submitFeedbackSQL;
   $resultFeedback = mysqli_query($connection,$submitFeedbackSQL)
          
          or die('Error creating feedback query');
          echo "<script language=\"JavaScript\">\n";
          echo "alert('You have submitted feedback!');\n";
          echo "window.location='../controller/index.php?page=4_homePage'";
          echo "</script>";
    }
}