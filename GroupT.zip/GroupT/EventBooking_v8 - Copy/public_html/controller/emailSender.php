<?php
//Controller to generate emails to attendees of an event in page 8_eventshost
$message = "Dear User, <br>"."Event, ".$hostRow['event_name']." is coming at ".$hostRow['start_date']." .The location is ".$hostRow['location_name'].". Don't miss out. <br>From,<br>Team LME";
$subject ="Upcoming events notice";
$header ="From: EventsBooking@gmail.com";


if(date("Y-m-d H:i:s")<$hostRow['start_date']){
    /*do{
        mail($atdRow['email'],$subject,$message,$header);
    }
    while (!empty($atdRow['email']));*/
    echo "<input type=\"submit\" value=\"Send emails\" name=\"toBooking\" onclick='back()'>";
};





