<?php
//Controller for account information table in 7_myAccount page
$connection = connect();
$accountSql = "SELECT account_id, username, email FROM account WHERE account_id='$user_id'";

$accountResult = mysqli_query($connection,$accountSql);
$accountRow = mysqli_fetch_array($accountResult);
$accountRow['account_id'];
$accountRow['username'];
$accountRow['email'];

?>