<?php
//Controller for event info in 9_events page
$connection=connect();
$event_id = (int)$_GET['event_id'];
//echo $event_id;
$eventInfoSql = "SELECT event_name, event_id, description, location_name, category_name, start_date, end_date, sale_start_date, sale_end_date FROM event JOIN location ON location.location_id=event.location_id JOIN category ON category.category_id=event.category_id WHERE event.event_id='$event_id'";
//echo $eventInfoSql;
$infoResult = mysqli_query($connection,$eventInfoSql);
$infoRow = mysqli_fetch_array($infoResult);
$infoRow['event_name'];
$infoRow['event_id'];
$infoRow['description'];
$infoRow['location_name'];
$infoRow['category_name'];
$infoRow['start_date'];
$infoRow['end_date'];
$infoRow['sale_start_date'];
$infoRow['sale_end_date'];
//check available tickets number
$capacitySql = "SELECT capacity FROM event JOIN location ON event.location_id = location.location_id WHERE event.event_id = '$event_id'";
$capacityResult = mysqli_query($connection,$capacitySql);
$capacityRow = mysqli_fetch_array($capacityResult);
$capacityRow['capacity'];
$ticketCheckSql = "SELECT COUNT(ticket.account_id) FROM event JOIN ticket ON event.event_id = ticket.event_id WHERE event.event_id = '$event_id'";
$ticketCheckResult = mysqli_query($connection,$ticketCheckSql);
$ticketCheckRow = mysqli_fetch_array($ticketCheckResult);
$ticketCheckRow['COUNT(ticket.account_id)'];
$ticketRemain = $capacityRow['capacity']-$ticketCheckRow['COUNT(ticket.account_id)'];
//check bought already or not
include ("../controller/checkState.php");
$boughtSql = "SELECT ticket_id FROM event JOIN ticket ON event.event_id = ticket.event_id WHERE ticket.event_id = '$event_id'AND ticket.account_id ='$user_id'";
$boughtResult = mysqli_query($connection,$boughtSql);
$boughtRow = mysqli_fetch_array($boughtResult);
$boughtRow['ticket_id'];
?>