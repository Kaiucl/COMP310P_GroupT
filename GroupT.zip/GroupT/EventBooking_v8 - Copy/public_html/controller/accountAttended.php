<?php
//Controller for attended events table in 7_myAccount page
$connection = connect();
$attendedSql = "SELECT event_name, end_date, event.event_id FROM ticket JOIN event ON event.event_id=ticket.event_id WHERE ticket.account_id='$user_id'";

$attendedResult = mysqli_query($connection,$attendedSql);
$attendedRow = mysqli_fetch_array($attendedResult);
$attendedRow['event_name'];
$attendedRow['end_date'];

if (empty($attendedRow)||date("Y-m-d H:i:s")<$attendedRow['end_date']){
    echo"
<table>
        <caption>Your attended Events</caption>
        <th>No attended events</th>
</table>";
}
else{
    echo"
  <table>
        <caption>Your Attended Events</caption>
        <tr>
            <th>Event Name</th>
            <th>End Date</th>
        </tr>
  </table>";

    do {if(date("Y-m-d H:i:s")>$attendedRow['end_date']){
        echo "<table>
           <tr>
               <td><a href=\"../php/11_submitFeedback.php?event_id={$attendedRow['event_id']}\">{$attendedRow['event_name']}</a></td>
               <td>{$attendedRow['end_date']}</td>
           </tr>
           </table>";
    }}
    while ($attendedRow = mysqli_fetch_array($attendedResult));
}

?>