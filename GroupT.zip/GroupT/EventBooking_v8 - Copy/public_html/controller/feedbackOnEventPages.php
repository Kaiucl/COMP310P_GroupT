<?php
//Controller for feedback table in 9_events page

include ("../controller/checkState.php");

$event_id = isset($_GET['event_id']);
//$event_id = isset($_GET['event_id']);
if (isset($_GET['event_id'])) {$event_id = (int)$_GET['event_id'];}
$displayFeedbackSQL = "SELECT text, rating, feedback.account_id, feedback.event_id, username FROM feedback JOIN account ON account.account_id=feedback.account_id WHERE feedback.event_id='$event_id'";
      
$displayFeedbackResult = mysqli_query($connection,$displayFeedbackSQL);
      $displayFeedbackRow = mysqli_fetch_array($displayFeedbackResult);
      $displayFeedbackRow['text'];
      $displayFeedbackRow['rating'];
      $displayFeedbackRow['account_id'];
      $displayFeedbackRow['event_id'];
      $displayFeedbackRow['username'];
      
      
    
    
if(mysqli_num_rows($displayFeedbackResult)>0){
   $displayAverageRatingSQL = "SELECT AVG(rating) FROM feedback JOIN account ON account.account_id=feedback.account_id WHERE feedback.event_id='$event_id'";
      
$displayAverageRatingResult = mysqli_query($connection,$displayAverageRatingSQL);
      $displayAverageRatingRow = mysqli_fetch_array($displayAverageRatingResult);
      $displayAverageRatingRow['AVG(rating)'];
      //echo $displayAverageRatingRow['AVG(rating)'];
      //do{
      // $averageRating=$displayAverageRatingRow['AVG(rating)'];
          
  //    }
//while ($displayAverageRatingRow = mysqli_fetch_array($displayAverageRatingResult));   
    
  echo "
    <h2>Feedback</h2>
    <text>Total Rating: {$displayAverageRatingRow['AVG(rating)']}</text>
    <table width=\"80%\">
        <tr>
            <th width=\"20%\">User Name</th>
            <th width=\"10%\">Rating</th>
            <th width=\"60%\">Text Review </th>
        </tr>  
    <table>
         ";
    
    
do { echo"
    <table width=\"80%\">         
        <tr> 
               <td width=\"20%\"> {$displayFeedbackRow['username']} </td>
               <td width=\"10%\"> {$displayFeedbackRow['rating']} </td>
               <td width=\"60%\"> {$displayFeedbackRow['text']} </td>
        </tr>
    </table>";
    }
    while ($displayFeedbackRow = mysqli_fetch_array($displayFeedbackResult));
}
else{
    echo "No feedback for this event";
}