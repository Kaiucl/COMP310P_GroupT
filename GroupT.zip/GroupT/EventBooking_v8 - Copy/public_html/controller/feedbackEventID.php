<?php
// Controller to store event seesion
$event_id = (int)$_GET['event_id'];
$_SESSION["feedback_event_id"]= $event_id;

$feedbackSQL = "SELECT event_name, event_id FROM event WHERE event.event_id='$event_id'";
//echo $feedbackSQL;

$feedbackResult = mysqli_query($connection,$feedbackSQL);
$feedbackRow = mysqli_fetch_array($feedbackResult);
$feedbackRow['event_name'];
$feedbackRow['event_id'];