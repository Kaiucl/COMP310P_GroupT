<?php
//Controller to display buy now button in 10_booking page
if (date("Y-m-d H:i:s")<$infoRow['start_date']) {
    if($ticketRemain > 0){
        if (date("Y-m-d H:i:s") < $infoRow['sale_end_date'] && date("Y-m-d H:i:s") > $infoRow['sale_start_date'] && empty($boughtRow['ticket_id'])) {
            echo "<a href=\"../php/10_booking.php?event_id={$infoRow['event_id']}\"><input type=\"submit\" value=\"Book Now!\" name=\"toBooking\"></a>";
        }
        if (!empty($boughtRow['ticket_id'])) {
            echo "<b>You have booked a ticket!</b>";
        }
    }
    if($ticketRemain <= 0){
        echo "<b>Tickets are sold out!</b>";
    }
    if (date("Y-m-d H:i:s") > $infoRow['sale_end_date']) {
        echo "<b>Sorry, the sale has finished.</b>";
    }
    if (date("Y-m-d H:i:s") < $infoRow['sale_start_date']) {
        echo "<b>Sorry, please wait for ticket sales to start </b>" . $infoRow['sale_start_date'];
    }
}
if (date("Y-m-d H:i:s")>$infoRow['end_date']){
    echo"<b>This event finished on </b>".$infoRow['end_date'];
}