<?php
//Controller for comfriming booking in 12_bookConfrim page

//find the account_id from session
$connection=connect();
$username=$_SESSION["user"];
$account_id = "SELECT account_id, username, email FROM account WHERE username =\"{$username}\"";
$accountIdResult = mysqli_query($connection,$account_id)
or die('Error making select location_id query' . mysql_error());
$accountRow = mysqli_fetch_array($accountIdResult);
$accountRow['account_id'];
$accountRow['email'];

$bookEvent_id = $_SESSION["event_id"];
$bookAccount_id = $accountRow['account_id'];

$buySql = "INSERT INTO ticket (event_id, account_id) VALUES ('$bookEvent_id',$bookAccount_id)";
$result = mysqli_query($connection,$buySql);

