<?php
//Controller to displey booking info in 10_booking page
$connection=connect();
$event_id = (int)$_GET['event_id'];
$_SESSION["event_id"]= (int)$_GET['event_id'];

$bookInfoSql = "SELECT event.event_name, event.start_date, event.end_date, location_name FROM event JOIN location ON event.location_id = location.location_id WHERE event.event_id ='$event_id'";
//echo $bookInfoSql;
$bookInfoResult = mysqli_query($connection,$bookInfoSql);
$bookInfoRow = mysqli_fetch_array($bookInfoResult);
$bookInfoRow['event_name'];
$bookInfoRow['start_date'];
$bookInfoRow['end_date'];
$bookInfoRow['location_name'];

//$ticketNumber = $_POST["ticket"];
//echo $ticketNumber;




