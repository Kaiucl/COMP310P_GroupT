<?php
if (!empty($atdRow['username'])){
do{echo $atdRow['username'].'<br>' ;}
while($atdRow = mysqli_fetch_array($atdResult));}

else{
echo"None";
}
?>