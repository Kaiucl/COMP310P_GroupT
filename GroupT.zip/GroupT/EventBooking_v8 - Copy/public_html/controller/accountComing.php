<?php
//Controller for coming events table in 7_myAccount page
$connection = connect();
$comingSql = "SELECT event_name, start_date, event.event_id FROM ticket JOIN event ON event.event_id=ticket.event_id WHERE ticket.account_id='$user_id' ORDER BY start_date DESC";
//echo $comingSql."coming";
$comingResult = mysqli_query($connection,$comingSql);
$comingRow = mysqli_fetch_array($comingResult);
$comingRow['event_name'];
$comingRow['start_date'];

$currentDate= date("Y-m-d H:i:s");
if($currentDate>$comingRow['start_date']){
    echo"
  <table>
        <caption>Your Upcoming Events</caption>
        <th>No upcoming events</th>
  </table>";
}

else{
    if(empty($comingRow)){
        echo"
  <table>
        <caption>Your Upcoming Events</caption>
        <th>No upcoming events</th>
  </table>";
    }
    else{
        echo"
  <table>
        <caption>Your Upcoming Events</caption>      
        <tr>
            <th>Event Name</th>
            <th>Start Date</th>
        </tr>
  </table>";

        do { if($currentDate<$comingRow['start_date']){
            echo "<table>
           <tr>
               <td><a href=\"../php/9_events.php?event_id={$comingRow['event_id']}\">{$comingRow['event_name']}</a></td>
               <td>{$comingRow['start_date']}</td>
               
           </tr>
           </table>";
        }}
        while ($comingRow = mysqli_fetch_array($comingResult ));
    }
}
               
//               <td><a href=\"../controller/index.php?page='.{$comingRow['event_id']}.'\">'.{$comingRow['event_name']}.'</a></td>
?>