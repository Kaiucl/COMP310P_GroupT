<?php
//Controller which controls the flow of pages for the website. This code is used to remember sessions between pages.
session_start();


if (isset($_GET['page']) == "") {
    include("../php/index.php");
}

if (isset($_GET['page']) && $_GET['page'] == "2_signUp") {
    include("../php/2_signUp.php");
}

if (isset($_GET['page']) && $_GET['page'] == "3_signIn") {
    include("../php/3_signIn.php");
}

if (isset($_GET['page']) && $_GET['page'] == "4_homePage") {
    include("../php/4_homePage.php");
}

if (isset($_GET['page']) && $_GET['page'] == "5_searchPage") {
    include("../php/5_searchPage.php");
}

if (isset($_GET['page']) && $_GET['page'] == "6_hostPage") {
    include("../php/6_hostPage.php");
}

if (isset($_GET['page']) && $_GET['page'] == "7_myAccount") {
    include("../php/7_myAccount.php");
}

if (isset($_GET['page']) && $_GET['page'] == "logOff") {
    include("../php/logOff.php");
}

if (isset($_GET['page']) && $_GET['page'] == "8_eventsHost") {
    include("../php/8_eventsHost.php");
}

if (isset($_GET['page']) && $_GET['page'] == "11_submitFeedback") {
    include("../php/11_submitFeedback");
}
?>