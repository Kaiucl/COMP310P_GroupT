<?php

function connect() {
    $dbhost = 'localhost';
    $dbuser = 'RoshS';
    $dbpass = 'Roshna11Shany';
    $dbname = 'lme';
    

$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname)
or die('Error connecting to MySQL server.'.
mysql_error());
return $connection;
}