<?php
//Controller for submitting the form to host an event in 6_hostPage
session_start();
include ("../controller/connect.php");
include ("../controller/checkState.php");

$event_name = $_POST["event_name"];
$category = $_POST["categories"];
$description = $_POST["description"];
$location = $_POST["location"];
$sale_start_date = $_POST["sale_start_date"];
$sale_end_date = $_POST["sale_end_date"];
$start_date = $_POST["start_date"];
$end_date = $_POST["end_date"];

function testInput($data) {
    $data = trim($data);
    return $data;
}

function stayOnPage($alerts) {
    echo "<script language=\"JavaScript\">\n";
    echo "alert('$alerts.');\n";
    echo "window.location='../php/6_hostPage.php'";
    echo "</script>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $connection = connect();

    $location_id = "SELECT location_id FROM location WHERE location_name =\"{$location}\"";
    $category_id = "SELECT category_id FROM category WHERE category_name =\"{$category}\"";

    $locationIdResult = mysqli_query($connection, $location_id)
            or die('Error making select location_id query' . mysql_error());
    $locationRow = mysqli_fetch_array($locationIdResult);
    $locationRow['location_id'];

    $categoryIdResult = mysqli_query($connection, $category_id)
            or die('Error making select category_id query' . mysql_error());
    $categoryRow = mysqli_fetch_array($categoryIdResult);
    $categoryRow['category_id'];

    $today = date("Y-m-d H:i:s");


    if ($start_date <= $today) {
        $alerts = "Please provide a valid start date";
        stayOnPage($alerts);
    } else if ($end_date <= $start_date) {
        $alerts = "Please provide an end date after the start date";
        stayOnPage($alerts);
    } else if ($sale_end_date <= $today) {
        $alerts = "Please provide a valid sale end date";
        stayOnPage($alerts);
    } else if ($start_date <= $sale_end_date) {
        $alerts = "Please provide a sale end date that finishes before the event start date";
        stayOnPage($alerts);
    } else if ($start_date <= $sale_start_date) {
        $alerts = "Please provide a sale start date that starts before the event start date";
        stayOnPage($alerts);
    } else {
        $event_name = testInput($event_name);
        $description = testInput($description);
        $location = testInput($location);
        $category_id = testInput($category_id);
        $sale_start_date = testInput($sale_start_date);
        $sale_end_date = testInput($sale_end_date);
        $start_date = testInput($start_date);
        $end_date = testInput($end_date);

        $connection = connect();
        $queryHost = "INSERT INTO event(event_name, description, location_id, account_id
          ,category_id, sale_start_date, sale_end_date, start_date, end_date)
          VALUES (\"{$event_name}\", \"{$description}\", \"{$locationRow['location_id']}\",\"{$user_id}\"
          ,\"{$categoryRow['category_id']}\", \"{$sale_start_date}\", \"{$sale_end_date}\",\"{$start_date}\" ,\"{$end_date}\" )";
        $result = mysqli_query($connection, $queryHost)
                or die('Error creating event query' . mysql_error());
        echo "<script language=\"JavaScript\">\n";
        echo "alert('You have created an event!');\n";
        echo "window.location='../controller/index.php?page=4_homePage'";
        echo "</script>";
    }
}