<?php
//Controller for search page qureys in 5_searchPage
if (empty($_POST["searchByName"])){
    $_POST["searchByName"]= NULL;
}
if (empty($_POST["searchByCategory"])){
    $_POST["searchByCategory"]= NULL;
}
if (empty($_POST["startDate"])){
    $_POST["startDate"]= NULL;
}
if (empty($_POST["endDate"])){
    $_POST["endDate"]= NULL;
}

//validation


if ($_POST["searchByName"] || $_POST["searchByCategory"] || $_POST["startDate"] || $_POST["endDate"]){
    $searchName = $_POST["searchByName"];
    $searchCategory = $_POST["searchByCategory"];
    $searchStart = $_POST["startDate"];
    $searchEnd = $_POST["endDate"];

    if(!empty($searchName)) {
        $sql[] = "event.event_name LIKE '%{$searchName}%'";
    }
    if(!empty($searchCategory)){
        $sql[] = "category.category_name='$searchCategory'";
    }
    if(!empty($searchStart)){
        $sql[] = "event.start_date > '$searchStart'";
    }
    if(!empty($searchEnd)){
        $sql[] = "event.start_date < '$searchEnd'";
    }

    $connection = connect();
    $sql = implode(' AND ', $sql);

    $sql = "SELECT event_name, start_date, category_name, location_name, event.event_id FROM event JOIN category ON event.category_id=category.category_id JOIN location ON event.location_id=location.location_id WHERE {$sql}";
    $result = mysqli_query($connection,$sql);
    $row = mysqli_fetch_array($result);
    $row['event_name'];
    $row['category_name'];
    $row['start_date'];


    if (empty($row)){
        echo "<table>
        <caption>No results found</caption>
        ";
    }

    else{
        $total = mysqli_num_rows($result);
        echo "<table>
        <caption> The number of results we found: $total</caption>
            <tr>
                <th>Event Name</th>
                <th>Location</th>
                <th>Category</th>
                <th>Dates</th>
            </tr>
            </table>";

        do {echo "<table>
           <tr>
               <td><a href=\"../php/9_events.php?event_id={$row['event_id']}\">{$row['event_name']}</a></td>
               <td>{$row['location_name']}</td> 
               <td>{$row['category_name']}</td> 
               <td>{$row['start_date']}</td>
           </tr>
           </table>";
        }
        while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC));
    }
}
