<?php
//Controller for events table in the homepage
//include ("../controller/connect.php");
$connection=connect();
$query="SELECT event_name, location_name, category_name, start_date, event.event_id
FROM event JOIN location ON location.location_id=event.location_id JOIN category ON category.category_id=event.category_id 
ORDER BY start_date DESC LIMIT 10";

$result=mysqli_query($connection,$query)or die('Error making select users query'.mysql_error());

$row = mysqli_fetch_array($result);
$row['event_name'];
$row['location_name'];
$row['category_name'];
$row['start_date'];

echo "
<table>
            <tr>
                <th>Event Name</th>
                <th>Location</th>
                <th>Category</th>
                <th>Dates</th>
            </tr>
</table>
";


do {echo "
<table>
           <tr>
               <td><a href=\"../php/9_events.php?event_id={$row['event_id']}\">{$row['event_name']}</a></td>
               <td>{$row['location_name']}</td> 
               <td>{$row['category_name']}</td> 
               <td>{$row['start_date']}</td>
           </tr>
</table> ";
}
while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC));

?>