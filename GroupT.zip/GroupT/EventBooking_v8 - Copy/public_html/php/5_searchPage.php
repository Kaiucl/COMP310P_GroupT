<?php
include ("../controller/connect.php");
include ("../php/navigation.php");
//HTML view for search page
?>

<html>
<head>
    <title>Search Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel ="stylesheet" href="../css/5_searchPage.css" />

</head>

<body>

<div class="searchBar">
    <form id="search" method="post" action="../php/5_searchPage.php">
        Name<input name="searchByName" type="text" placeholder="Name of events"><br>
        Category<select name="searchByCategory">
            <option disabled selected value> -- select an option -- </option>
            <option>classic</option>
            <option>rock</option>
            <option>hip-hop</option>
            <option>country</option>
        </select><br>
        Timeframe
        between
        <input type="date" name="startDate" placeholder="2017-12-10">
        and
        <input type="date" name="endDate" placeholder="2019-12-10"><br>
        <p>Please enter your dates and times in the form: yyyy-mm-dd </p>
        <!-- 
            In the above input fields, a placeholder is inserted to help the user insert the date in the correct format. 
            This is done because certain web browsers do not automatically format date 
        -->
        <input type="submit" value="Search">
    </form>
</div>

</body>
</html>


<?php
include ("../controller/research.php");
?>



