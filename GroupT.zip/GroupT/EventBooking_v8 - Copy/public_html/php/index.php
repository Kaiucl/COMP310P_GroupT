<!DOCTYPE html>
<html>
     <!--HTML view for landing page
   -->
<head>
    <title>Landing Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/index.css"/>
</head>

<body>
<header>
    <img src="../logo.JPG" alt="logo">
    <br><br>
</header>

<div id="websiteDescription">
    We at London Musical Events are events company specialising in helping you to create the PERFECT event. We have a range of small and large venues suited to your needs, to provide you with the BEST experience. You can not only host events, but also attend events created by fellow likeminded people.
</div>
<div>
    <a href="../php/3_signIn.php"><input type="submit" id="in" value="Sign In"></a>
    <a href="../php/2_signUp.php"><input type="submit" id="up" value="Sign Up"></a>
</div>

</body>
</html>
