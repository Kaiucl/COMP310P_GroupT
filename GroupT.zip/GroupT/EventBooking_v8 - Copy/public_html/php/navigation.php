<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- Adapted from "https://www.w3schools.com/howto/howto_js_topnav.asp" [Accessed on 2/12/2017] -->
</head>
<!--HTML view for navigation bar
   -->
<body>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="../controller/index.php?page=4_homePage">LME Home</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="../controller/index.php?page=7_myAccount">My Account</a></li>
            <li><a href="../controller/index.php?page=6_hostPage">Host an Event</a></li>
            <li><a href="../controller/index.php?page=5_searchPage">Search</a></li>
        </ul>
    </div>
</nav>
</body>