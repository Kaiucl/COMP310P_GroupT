<?php
include ("../controller/connect.php");
//HTML view for sign up page
?>
    
<!DOCTYPE html>
<html>
<head>
    <title>SignIn</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/3_signIn.css"/>
</head>
<body>

<div class="login">
    <form method="post" action="../controller/login.php">
    Username:
    <input type="text" name="username" required>
    <br>
    Password:
    <input type="password" name="password" required>
    <br>
    
    <!--<a href="4_homePage.html">
    -->
    <input type="submit" value="Sign In" id="si_signIn">
    <!--
    </a>
    <a href="../html/index.html">
    -->
    <input type="submit" value="Cancel" id="si_backHome" onClick="window.location='../php/index.php';"/>
    <!--</a> --> 
    
    </form>
    
</div>

</body>
</html>