<?php
//HTML view for dynamic booking confirmation page
session_start();
include ("../controller/connect.php");
include ("../php/navigation.php");
include ("../controller/bookConfirm.php");
include ("../controller/checkState.php");
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking Confirmation</title>
    <link rel="stylesheet" href="../css/12_bookConfirm.css">
</head>
<body>

<div class="confirm">
    <br><br><br>
    <b>Congratulations, Your book is completed!</b>
    <br>
    <b><?php echo "An email will be sent to ".$accountRow['email']." when this upcoming event is close."  ?></b>
    <br><br><br>
</div>

</body>
</html>