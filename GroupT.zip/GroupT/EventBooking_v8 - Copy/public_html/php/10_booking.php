<?php
//HTML view for booking page
session_start();
include ("../controller/connect.php");
include ("../php/navigation.php");
include ("../controller/booking.php");
include ("../controller/checkState.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking</title>
    <link rel="stylesheet" href="../css/10_booking.css">
</head>
<body>

<form method="post" action="../php/12_bookConfirm.php">
<div class="b_1">
    <h3>Event Details</h3>
    <b>Event Name:</b><?php echo " ".$bookInfoRow['event_name']; ?>
    <br>
    <b>Location:</b><?php echo " ".$bookInfoRow['location_name']; ?>
    <br>
    <b>Start Date:</b><?php echo " ".$bookInfoRow['start_date']; ?>
    <br>
    <b>End Date:</b><?php echo " ".$bookInfoRow['end_date']; ?>
    <br>
    <b>Book: 1 Ticket
    <br>
</div>
<div class="b_2">
    <h3>Your Details</h3>
    <b>Username:</b><?php echo " ".$accountRow['username'];; ?>
    <br>
    <b>Email:</b><?php echo " ".$accountRow['email'];; ?>
    <br>
    <br>
    <input type="submit" id="b_a" value="Confirm">
</div>
</form>

</body>
</html>