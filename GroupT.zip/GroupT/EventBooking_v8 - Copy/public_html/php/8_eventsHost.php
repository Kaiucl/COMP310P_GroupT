<?php
include "../controller/connect.php";
include ('../php/navigation.php');
//HTML view for detailed attendees list of the event for the host viewing
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EventsHost</title>
    <link rel="stylesheet" href="../css/8_eventsHost.css">
</head>

<body>
<?php
include ('../controller/yourHostInfo.php');

?>
<div class="eh_1"style="float: left; width: 100%;">
    <h2><?php echo $hostRow['event_name']  ?></h2>

    <table>
        <tr>
            <th width="10%">Start Date</th>
            <th width="10%">Tickets Remaining</th>
            <th width="10%">Location</th>
            <th width="20%">Attendee List</th>
        </tr>
        <tr>
            <td><?php echo $hostRow['start_date']  ?></td>
            <td><?php echo $ticketRemain ?></td>
            <td><?php echo $hostRow['location_name'] ?></td>
            <td><?php
                  include ("../controller/attendeeList.php");
                ?>
            </td>
        </tr>
    </table>

    <?php
    include ('../controller/emailSender.php');
    ?>
    <script>
        function back(){
            alert('You have sent the emails to attendees!');
            window.location='../controller/index.php?page=4_homePage'
        }
    </script>
</div>
</body>
</html>