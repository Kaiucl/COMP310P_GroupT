<?php
include ("../php/navigation.php");
//HTML view for host page
?>

<html>
<head>
    <title>Host your event</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel ="stylesheet" href="../css/6_hostPage.css" />
</head>

<body>
<div class="hostEventForm">
    <form method="post" action="../controller/hostPage.php" class="HostForm">
        <br>
        Event Name <input type="text" name="event_name" placeholder="Event Name" value="" required>
        <div class="help">?
            <span class="helpText">Please enter the name of the Event </span>
        </div>
        <br>
        Category
        <!--<input type="text" placeholder="Category" required>
        -->
        <select id="Genre" name="categories" size ="1" required>

            <option value="rock">rock</option>
            <option value="classic">classic</option>
            <option value="hiphop">hiphop</option>
            <option value="country">country</option>


        </select>
        <div class="help">?
            <span class="helpText">Please choose the music genre that most closely describes the event</span>
        </div>
        <br>
        Description <input name="description" type="text" placeholder="Description" value="" required>
        <div class="help">?
            <span class="helpText">Please enter a description for the event</span>
        </div>
        <br>
        Location <select name="location" required>
            <optgroup label="Large location">
                <option>The O2 Arena</option>
                <option>Wembley Arena</option>
                <option>Royal Albert Hall</option>
            </optgroup>
            <optgroup label="Small location">
                <option>Richard Mully's Basement Bar</option>
                <option>The Huntley</option>
            </optgroup>
        </select> <div class="help">?
            <span class="helpText">Please enter the location of the event</span>
        </div>
        <br>
        <!-- 
            In the following input fields, a value is inserted as a placeholder to help the user insert the date in the correct format. 
            This is done because certain web browsers do not automatically format datetime-local 
        -->
        Start Date
        <input name="start_date" type="datetime-local" id="startDate" value="2018-12-11 12:20:20" required>
        <div class="help">?
            <span class="helpText">Please enter the start date of the event</span>
        </div>
        <br>
        End Date
        <input name="end_date" type="datetime-local" id="endDate" value="2018-12-12 12:20:20" required>
        <div class="help">?
            <span class="helpText">Please enter the end date of the event</span>
        </div>
        <br>
        Sale Start Date
        <input name="sale_start_date" type="datetime-local" id="saleStartDate" value="2018-12-09 12:20:20" required>
        <div class="help">?
            <span class="helpText">Please enter the day that ticket sales will start</span>
        </div>
        <br>
        Sale End Date
        <input name="sale_end_date" type="datetime-local" id="saleEndDate" value="2018-12-10 12:20:20" required>
        <div class="help">?
            <span class="helpText">Please enter the day that ticket sales will end</span>
        </div>
        <br>
        <input type="submit" value="Confirm" id="confirmButtonHostPage">

    </form>
</div>

<div class="hostNotice">
    <p>Notice:</p>
    <ul>
        <li>Maximum length of event name is 20 words</li>
        <li>The location choices available have the following capacities: </li>
    </ul>
    <p>
        The O2 Arena (2000)<br>
        Wembley Arena (1000)<br>
        Royal Albert Hall (500)<br>
        Richard Mully's Bar (100)<br>
        The Huntley (30)<br>
    </p>
    <ul>
        <li>The number of tickets available for each venue will be the venue's capacity</li>
        <li>Please enter your dates and times in the form: yyyy-mm-dd hh:mm:ss</li>
    </ul>


</div>


</body>
</html>