<?php
include "../controller/connect.php";
include("../php/navigation.php");
//HTML view for my account page
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Account</title>
    <link rel="stylesheet" href="../css/7_myAccount.css">
</head>
<body>

<?php
include("../controller/checkState.php");
?>

<div class="acc_1">
    <?php
    include ("../controller/accountInfo.php");
    echo "
    <h3>Account Information</h3>
    <text>Account ID:</text><text>{$accountRow['account_id']}</text>
    <br>
    <text>User Name:</text><text>{$accountRow['username']}</text>
    <br>
    <text>Email:</text><text>{$accountRow['email']}</text>
    <br>
    ";
    ?>
<a href="../controller/index.php?page=logOff"><input type="submit" value="log off"></a>
</div>

<div class="acc_2">
    <?php
    include ("../controller/accountComing.php");
    echo "(Click on event names to see event details)";
    ?>
</div>

<div class="acc_3">
    <?php
    include ("../controller/accountHosted.php");
    echo "(Click on event names to see sale progress and attendee list)";
    ?>
</div>

<div class="acc_4">
    <?php
    include ("../controller/accountAttended.php");
    echo "(Click on event names to write feedback)";
    ?>
</div>


</body>
</html>


