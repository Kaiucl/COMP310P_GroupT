<html>
      <!--HTML view for sign up page
   -->
<head>
    <title>SignUp</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/2_signUp.css"/>

</head>
<body>
    <form method="post" action="../controller/signUp.php" >
<div class="form">
    First Name:<br>
    <input type="text" name="firstName" required>
    <div class="help">?
    <span class="helpText">Please enter your first name</span>
    </div>
    <br>
    Last Name:<br>
    <input type="text" name="lastName" required>
    <div class="help">?
    <span class="helpText">Please enter your surname</span>
    </div>
    <br>
    Username:<br>
    <input type="text" name="username" required>
    <div class="help">?
    <span class="helpText">Enter a username that you will use to log in </span>
    </div>
    <br>
    Email:<br>
    <input id="email" type="email" name="email" maxlength="50" required>
    <div class="help">?
    <span class="helpText">Enter your email address</span>
    </div>
    <br>
    Password:<br>
    <input type="password" name="password" required>
    <div class="help">?
    <span class="helpText">Password length must greater than eight with at least one letter</span>
    </div>
    <br>
    Confirm Password:<br>
    <input type="password" name="password1" required>
    <div class="help">?
    <span class="helpText">Confirm your password</span>
    </div>
    <br>


    <input type="submit" value="Sign Up" id="su_signUp">

    <input type="submit" value="Cancel" id="su_backHome" onClick="window.location='../php/index.php';"/>


</div>
</form>
    
</body>
</html>