<?php
include ("../php/navigation.php");
include ("../controller/connect.php");
include ("../controller/checkState.php");
//HTML view for home page
?>

<html>
<head>
    <title>Home Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/4_homePage.css"/>
</head>
<body>

<div class="recentEvents">
    <h3>Recent Events</h3><p>View recent excellent events, never miss a chance to book tickets! </p>
    <?php
    include("../controller/home.php");
    ?>
</div>


</body>
</html>


