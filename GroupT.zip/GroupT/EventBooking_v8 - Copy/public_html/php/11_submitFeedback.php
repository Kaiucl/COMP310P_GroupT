<?php
//HTML view for dynamic feedback page
include ("../php/navigation.php");
include ("../controller/submitFeedback.php");
include "../controller/feedbackEventID.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Writing your feedback</title>
    <link rel="stylesheet" href="../css/11_submitFeedbeck.css">
</head>

<body>
<div class="sf_1">
    <h3>Event Name: <?php echo $feedbackRow['event_name'];  ?></h3>
</div>

<div class="sf_2">
    <form method="post" action="../controller/submitFeedback.php" >

    <b>Your Rating</b>
    <select name="rating" required>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option selected>5</option>
    </select>
    <br>
    <b>Your Text Feedback</b>
    <br>
    <input type="text" id="comment" name="feedback_text" value="" maxlength="200" placeholder="Write your comment here...">
    <br>
    <input type="submit" id="sf_b" value="Submit" >
    </form>
</div> 




</body>
</html>