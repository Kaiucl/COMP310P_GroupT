<?php
//HTML view for log off
session_destroy();
include ("../php/index.php");
echo "<script language=\"JavaScript\">\n";
echo "alert('You have logged off');\n";
//echo "window.location='../controller/index.php?page=index'";
echo "</script>";

