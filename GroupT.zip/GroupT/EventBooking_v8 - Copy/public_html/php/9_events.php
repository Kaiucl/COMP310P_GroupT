<?php
//HTML view for dynamic events page
session_start();
include ("../controller/connect.php");
include ("../controller/eventInfo.php");
include ("../php/navigation.php");
include ("../controller/checkState.php");
//include ("../controller/feedbackOnEventPages.php");
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php  echo $infoRow['event_name']; ?></title>
    <link rel="stylesheet" href="../css/9_events.css">
</head>
<body>

<div class="e_1">
    <b>Event Name:</b><?php  echo $infoRow['event_name']; ?>
    <br><br>
    <b>Event ID:</b><?php  echo $infoRow['event_id']; ?>
    <br><br>
    <b>Description:</b><?php  echo $infoRow['description']; ?>
    <br><br>
    <b>Category:</b><?php  echo $infoRow['category_name']; ?>
    <br><br>
    <?php
    include ("../controller/buyNow.php");
    ?>
</div>


<div class="e_2">
    <b>Start Date:</b><text></text><?php  echo $infoRow['start_date']; ?>
    <br><br>
    <b>End Date:</b><text></text><?php  echo $infoRow['end_date']; ?>
    <br><br>
    <b>Sale Start Date:</b><text></text><?php  echo $infoRow['sale_start_date']; ?>
    <br><br>
    <b>Sale End Date:</b><text></text><?php  echo $infoRow['sale_end_date']; ?>
    <br><br>
    <b>Address:</b><text></text><?php  echo $infoRow['location_name']; ?>
</div>

<div class="e_3">
    <?php include ("../controller/feedbackOnEventPages.php"); ?>
</div>

</body>
